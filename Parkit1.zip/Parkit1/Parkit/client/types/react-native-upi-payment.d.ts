declare module 'react-native-upi-payment';
