import cv2
import pytesseract
import firebase_admin
from firebase_admin import credentials, firestore
from datetime import datetime, timezone
import time
import re
from google.cloud.firestore import SERVER_TIMESTAMP

# Initialize Firebase Admin SDK
cred = credentials.Certificate("Parkit\\server\\dbcred.json")
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://parkcam-55b53-default-rtdb.firebaseio.com'
})

# Get Firestore client
firestore_db = firestore.client()

# Path to Tesseract executable
pytesseract.pytesseract.tesseract_cmd = r'C:\\Program Files\\Tesseract-OCR\\tesseract.exe'

def clean_text(text):
    cleaned_text = text.strip()
    cleaned_text = re.sub(r'[^a-zA-Z0-9]', '', cleaned_text)
    cleaned_text = cleaned_text.upper()
    cleaned_text = cleaned_text[:10]
    return cleaned_text

def recognize_plate():
    plate_cascade = cv2.CascadeClassifier("C:\\Users\\amaan\\Desktop\\Parkit1\\Parkit\\server\\plate_recog.xml")
    cap = cv2.VideoCapture(0)

    if not cap.isOpened():
        print("Error: Could not open camera")
        return None

    while True:
        ret, frame = cap.read()
        if not ret:
            print("Error: Could not read frame")
            continue

        frame = cv2.resize(frame, (640, 480))
        cv2.rectangle(frame, (100, 100), (540, 360), (0, 255, 0), 2)
        gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
        blurred = cv2.GaussianBlur(gray, (5, 5), 0)
        thresh = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY_INV, 11, 2)
        
        plates = plate_cascade.detectMultiScale(thresh, scaleFactor=1.1, minNeighbors=5, minSize=(30, 30))
        
        for (x, y, w, h) in plates:
            if 100 < x < 440 and 100 < y < 380:
                roi = frame[y:y + h, x:x + w]
                cv2.rectangle(frame, (x, y), (x + w, y + h), (0, 255, 0), 2)
                roi_gray = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
                plate_text = pytesseract.image_to_string(roi_gray, config='--psm 7')
                cleaned_plate_number = clean_text(plate_text)
                
                if re.match(r'^[A-Z]{2}\d{2}[A-Z]{2}\d{4}$', cleaned_plate_number):
                    print("License Plate Number:", cleaned_plate_number)
                    cap.release()
                    cv2.destroyAllWindows()
                    return cleaned_plate_number
        
        cv2.imshow('Frame', frame)
        if cv2.waitKey(1) & 0xFF == ord('q'):
            break

    cap.release()
    cv2.destroyAllWindows()
    return None

def check_access(plate_number):
    user_bookings_ref = firestore_db.collection('user_bookings')
    query = user_bookings_ref.where('plate_no', '==', plate_number)
    results = query.stream()
    
    for doc in results:
        data = doc.to_dict()
        entry_time = data['entry_time']
        if isinstance(entry_time, datetime):
            entry_time = entry_time.replace(tzinfo=timezone.utc)  # Keep it as datetime, just ensure UTC timezone
        else:
            entry_time = datetime.strptime(entry_time, '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc)  # Convert if string
        exit_time = datetime.strptime(data['exit_time'], '%Y-%m-%dT%H:%M:%SZ').replace(tzinfo=timezone.utc)
        
        if entry_time <= datetime.now(timezone.utc) <= exit_time:
            print("Access Granted! Opening Gate...")
            open_gate()
            return
    
    print("Access Denied! No valid booking found.")

def open_gate():
    print("[SYSTEM] Gate Opening... 🚗💨")
    time.sleep(2)  # Simulate gate opening delay
    print("[SYSTEM] Gate Closed 🚧")

if __name__ == "__main__":
    plate_number = recognize_plate()
    if plate_number:
        check_access(plate_number)
